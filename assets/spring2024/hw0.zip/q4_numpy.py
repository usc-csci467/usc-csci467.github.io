"""Code for HW0 Problem 4: numpy & gradient descent."""
import argparse
import sys

import numpy as np

def f(x, u, v):
    """Compute f(x) using the given values of u and v."""
    ### BEGIN_SOLUTION 4a
    raise NotImplementedError
    ### END_SOLUTION 4a

def grad_f(x, u, v):
    """Compute gradient of f(x) using the given values of u and v."""
    ### BEGIN_SOLUTION 4c
    raise NotImplementedError
    ### END_SOLUTION 4c


def find_optimum(u, v, learning_rate=1e-1, num_iters=100):
    """Find the x that minimizes f(x) given values of u and v."""
    dim = u.shape[0]  # Dimension of u
    ### BEGIN_SOLUTION 4d
    raise NotImplementedError
    ### END_SOLUTION 4d

def run_gradient_descent(u, v):
    print(f'\nRunning gradient descent with u={u}, v={v}')
    x = find_optimum(u, v)
    print('Optimal x: ', x)
    print('Optimal f(x): ', f(x, u, v))

def main():
    # 2-dimensional test-case
    run_gradient_descent(np.array([1, 5]), np.array([1, 0]))

    # 3-dimensional test-case
    run_gradient_descent(np.array([-1, 3, 2]), np.array([2, -3, 1]))


if __name__ == '__main__':
    main()

