"""Code for HW0 Problem 4: numpy & gradient descent."""
import argparse
import sys

import numpy as np

u = np.array([1, 5])
v = np.array([1, 0])

def f(x):
    ### BEGIN_SOLUTION 4a
    raise NotImplementedError
    ### END_SOLUTION 4a

def grad_f(x):
    ### BEGIN_SOLUTION 4c
    raise NotImplementedError
    ### END_SOLUTION 4c


def find_optimum(learning_rate=1e-1, num_iters=100):
    ### BEGIN_SOLUTION 4d
    raise NotImplementedError
    ### END_SOLUTION 4d

def main():
    x = find_optimum()
    print('Optimal x: ', x)
    print('Optimal f(x): ', f(x))

if __name__ == '__main__':
    main()

