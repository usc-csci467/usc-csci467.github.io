"""Code for HW4 Problem 1: Word Vectors and PCA."""
import argparse
import sys

import matplotlib.pyplot as plt
import numpy as np

OPTS = None

def find_neighbors(vocabulary, word_vectors, query, k):
    """Find closest words to given word by cosine similarity of word vectors.

    Args:
        - vocabulary: List of words of length N
        - word_vectors: Matrix of shape (N, D) where D is the size of each word vector
        - query: vector to find neighbors for
        - k: Number of neighbors to retrieve

    Returns: A list of length k sorted from most similar to least similar,
        where each entry is a tuple (neighbor_word, cosine_similarity)
    """
    N, D = word_vectors.shape
    neighbors = []

    ### BEGIN_SOLUTION 4a
    raise NotImplementedError
    ### END_SOLUTION 4a
    return neighbors

def query_relation(vocabulary, word_vectors, head1, tail1, head2):
    """Answer relational/analogical query using word vectors.

    Answers the relation query "head1 is to tail1 as head2 is to ___"

    Args:
        - vocabulary: List of words of length N
        - word_vectors: Matrix of shape (N, D) where D is the size of each word vector
        - head1: First "head" word. Must be in vocabulary.
        - tail1: First "tail" word. Must be in vocabulary.
        - head2: Second "head" word. Must be in vocabulary.

    Returns: Best guess of the second "tail" word.
    """
    query = None
    # TODO: Compute the appropriate query vector to feed to find_neighbors
    ### BEGIN_SOLUTION 4c
    raise NotImplementedError
    ### END_SOLUTION 4c

    neighbors = find_neighbors(vocabulary, word_vectors, query, 10)
    for word, cossim in neighbors:
        # Avoid returning the original head2 or tail1 words
        if word != head2 and word != tail1:
            return word


def project_2d(X):
    """Find a 2-dimensional projection of the vectors for visualization.

    Your code should do the following:
        1. Mean-center the data matrix X
        2. Compute the covariance matrix of the data
        3. Get the eigenvectors of the data
        4. Find the eigenvectors corresponding to the largest 2 eigenvalues
        5. Project each original vector onto these two eigenvectors
    This final step results in a 2-dimensional vector for each original D-dimensional vector,
    which you should return as a N x 2 matrix.

    Args:
        - X: Matrix of shape (N, D) where D is the size of each word vector

    Returns: Matrix of shape (N, 2) where the i-th row is the 2-dimensional projection
        of the i-th word in word_list.
    """
    ### BEGIN_SOLUTION 4e
    raise NotImplementedError
    ### END_SOLUTION 4e


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['neighbors', 'relation', 'visualize'])
    parser.add_argument('--num-neighbors', '-k', type=int)
    parser.add_argument('--query', '-q')
    parser.add_argument('--word-file', '-f')
    return parser.parse_args()


def main():
    with open('vocab.txt') as f:
        vocabulary = [line.strip() for line in f]
    word_vectors = np.load('vectors.npy')

    if OPTS.mode == 'neighbors':
        if OPTS.query in vocabulary:
            query_idx = vocabulary.index(OPTS.query)
            query_vector = word_vectors[query_idx,:]
        else:
            print(f'Query word "{OPTS.query}" not in vocabulary.')
            sys.exit(1)
        neighbors = find_neighbors(vocabulary, word_vectors, query_vector, OPTS.num_neighbors)
        for (neighbor, similarity) in neighbors:
            print(f'{neighbor}: {similarity:.4f}')
    if OPTS.mode == 'relation':
        head1, tail1, head2 = OPTS.query.split(',')
        answer = query_relation(vocabulary, word_vectors, head1, tail1, head2)
        print(answer)
    if OPTS.mode == 'visualize':
        with open(OPTS.word_file) as f:
            word_list = [word.strip() for word in f]

        # Get the associated word vectors
        cur_vecs = []
        for word in word_list:
            cur_vecs.append(word_vectors[vocabulary.index(word),:])
        X = np.array(cur_vecs)  # N, D

        projection = project_2d(X)
        fig, ax = plt.subplots(figsize=(10, 10))
        ax.scatter(projection[:,0], projection[:,1])
        plt.xlabel('PC1')
        plt.ylabel('PC2')
        for i, word in enumerate(word_list):
            ax.annotate(word, (projection[i,0], projection[i,1]))
        for i in range(len(word_list) // 2):
            delta = projection[2*i+1,:] - projection[2*i,:]
            ax.arrow(projection[2*i,0], projection[2*i,1], delta[0], delta[1])
        plt.savefig('visual.png')


if __name__ == '__main__':
    OPTS = parse_args()
    main()

